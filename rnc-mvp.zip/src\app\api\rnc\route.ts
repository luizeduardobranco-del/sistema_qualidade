import { NextResponse } from "next/server";

export async function GET() {
  // TODO: replace with Supabase query + filters
  return NextResponse.json({ items: [] });
}

export async function POST(req: Request) {
  // TODO: validate payload + insert in Supabase + start SLA logs
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  return NextResponse.json(
    {
      id: 0,
      status: "Aberta",
      created_at: new Date().toISOString()
    },
    { status: 201 }
  );
}

